﻿/*
  Copyright (c) 2011-2013, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Apr 15, 2014 19:53+0000 for FHIR v0.80
 */
/*
 * (informative) A response to a scheduled appointment for a patient and/or practitioner(s)
 *
 * [FhirResource("AppointmentResponse")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRIdentifier;
@class FHIRResource;
@class FHIRCodeableConcept;
@class FHIRCode;
@class FHIRString;
@class FHIRInstant;
@class FHIRDateTime;

@interface FHIRAppointmentResponse : FHIRBaseResource

/*
 * The Participation status of an appointment
 */
typedef enum 
{
    kParticipantStatusAccepted, // The appointment participant has accepted that they can attend the appointment at the time specified in the AppointmentResponse.
    kParticipantStatusDeclined, // The appointment participant has declined the appointment.
    kParticipantStatusTentative, // The appointment participant has tentatively accepted the appointment.
    kParticipantStatusInProcess, // The participant has in-process the appointment.
    kParticipantStatusCompleted, // The participant has completed the appointment.
    kParticipantStatusNeedsAction, // This is the intitial status of an appointment participant until a participant has replied. It implies that there is no commitment for the appointment.
} kParticipantStatus;

/*
 * External Ids for this item
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * Parent appointment that this response is replying to
 */
@property (nonatomic, strong) FHIRResource *appointment;

/*
 * Role of participant in the appointment
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *participantType;

/*
 * A Person of device that is participating in the appointment, usually Practitioner, Patient, RelatedPerson or Device
 */
@property (nonatomic, strong) NSArray/*<ResourceReference>*/ *individual;

/*
 * accepted | declined | tentative | in-process | completed | needs-action
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *participantStatusElement;

@property (nonatomic) kParticipantStatus participantStatus;

/*
 * Additional comments about the appointment
 */
@property (nonatomic, strong) FHIRString *commentElement;

@property (nonatomic, strong) NSString *comment;

/*
 * Date/Time that the appointment is to take place
 */
@property (nonatomic, strong) FHIRInstant *startElement;

@property (nonatomic, strong) NSDate *start;

/*
 * Date/Time that the appointment is to conclude
 */
@property (nonatomic, strong) FHIRInstant *endElement;

@property (nonatomic, strong) NSDate *end;

/*
 * Who recorded the appointment response
 */
@property (nonatomic, strong) FHIRResource *lastModifiedBy;

/*
 * Date when the response was recorded or last updated
 */
@property (nonatomic, strong) FHIRDateTime *lastModifiedByDateElement;

@property (nonatomic, strong) NSString *lastModifiedByDate;

- (FHIRErrorList *)validate;

@end
