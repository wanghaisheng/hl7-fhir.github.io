﻿/*
  Copyright (c) 2011-2013, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Thu, Apr 3, 2014 04:12+0000 for FHIR v0.80
 */
/*
 * System of unique identification
 *
 * [FhirResource("Namespace")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRCode;
@class FHIRString;
@class FHIRCodeableConcept;
@class FHIRNamespaceUniqueIdComponent;
@class FHIRResource;
@class FHIRNamespaceContactComponent;

@interface FHIRNamespace : FHIRBaseResource

/*
 * Indicates whether the namespace should be used
 */
typedef enum 
{
    kNamespaceStatusProposed, // System has been submitted but not yet approved.
    kNamespaceStatusActive, // System is valid for use.
    kNamespaceStatusRetired, // System should no longer be used.
} kNamespaceStatus;

/*
 * Identifies the purpose of the namespace
 */
typedef enum 
{
    kNamespaceTypeCodesystem, // The namespace is used to define concepts and symbols to represent those concepts.  E.g. UCUM, LOINC, NDC code, local lab codes, etc.
    kNamespaceTypeIdentifier, // The namespace is used to manage identifiers (e.g. license numbers, order numbers, etc.).
    kNamespaceTypeRoot, // The namespace is used as the root for other identifiers and namespaces.
} kNamespaceType;

/*
 * Identifies the style of unique identifier used to identify a namepace
 */
typedef enum 
{
    kNamespaceIdentifierTypeOid, // An ISO object identifier.  E.g. 1.2.3.4.5.
    kNamespaceIdentifierTypeUuid, // A universally unique identifier of the form a5afddf4-e880-459b-876e-e4591b0acc11.
    kNamespaceIdentifierTypeUri, // A uniform resource identifier (ideally a URL - uniform resource locator).  E.g. http://unitsofmeasure.org.
    kNamespaceIdentifierTypeRuid, // HL7-assigned reserved string.  E.g. LN for LOINC.
} kNamespaceIdentifierType;

/*
 * Identifies the general purpose of the namespace identifiers provided
 */
typedef enum 
{
    kNamespaceCategoryDriver, // Driver's license/operator's license.
    kNamespaceCategoryProvider, // Provider license or registration id.
    kNamespaceCategoryPatient, // Patient record numbers, jurisdictional patient ids, etc.
    kNamespaceCategoryBank, // Credit, debit and other bank card identifiers.
} kNamespaceCategory;

/*
 * codesystem | identifier | root
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *typeElement;

@property (nonatomic) kNamespaceType type;

/*
 * Human-readable name
 */
@property (nonatomic, strong) FHIRString *labelElement;

@property (nonatomic, strong) NSString *label;

/*
 * proposed | active | retired
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kNamespaceStatus status;

/*
 * ISO 3-char country code
 */
@property (nonatomic, strong) FHIRCode *countryElement;

@property (nonatomic, strong) NSString *country;

/*
 * driver | provider | patient | bank
 */
@property (nonatomic, strong) FHIRCodeableConcept *category;

/*
 * What does namespace identify?
 */
@property (nonatomic, strong) FHIRString *descriptionElement;

@property (nonatomic, strong) NSString *description;

/*
 * How/where is it used
 */
@property (nonatomic, strong) FHIRString *usageElement;

@property (nonatomic, strong) NSString *usage;

/*
 * Unique identifiers used for system
 */
@property (nonatomic, strong) NSArray/*<NamespaceUniqueIdComponent>*/ *uniqueId;

/*
 * Who maintains system namespace?
 */
@property (nonatomic, strong) FHIRResource *responsible;

/*
 * Who should be contacted for questions about namespace
 */
@property (nonatomic, strong) FHIRNamespaceContactComponent *contact;

- (FHIRErrorList *)validate;

@end
