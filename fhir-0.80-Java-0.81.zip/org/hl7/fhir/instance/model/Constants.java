package org.hl7.fhir.instance.model;

public class Constants {

  public final static String VERSION = "0.80";
  public final static String REVISION = "????";
  public final static String DATE = "Sun Apr 13 23:14:52 UTC 2014";
}
