package org.hl7.fhir.instance.model;

public class Constants {

  public final static String VERSION = "0.80";
  public final static String REVISION = "????";
  public final static String DATE = "Tue Apr 15 02:00:01 UTC 2014";
}
