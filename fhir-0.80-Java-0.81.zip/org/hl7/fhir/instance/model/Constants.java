package org.hl7.fhir.instance.model;

public class Constants {

  public final static String VERSION = "0.80";
  public final static String REVISION = "????";
  public final static String DATE = "Tue Apr 15 06:55:02 UTC 2014";
}
