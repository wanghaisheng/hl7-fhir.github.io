package org.hl7.fhir.instance.model;

public abstract class PrimitiveType extends Type {

  public abstract String asStringValue();
  
}
