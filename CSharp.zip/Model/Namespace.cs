﻿using System;
using System.Collections.Generic;
using Hl7.Fhir.Introspection;
using Hl7.Fhir.Validation;
using System.Linq;
using System.Runtime.Serialization;

/*
  Copyright (c) 2011-2013, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

*/

//
// Generated on Thu, Apr 10, 2014 08:34+0000 for FHIR v0.80
//
namespace Hl7.Fhir.Model
{
    /// <summary>
    /// System of unique identification
    /// </summary>
    [FhirType("Namespace", IsResource=true)]
    [DataContract]
    public partial class Namespace : Hl7.Fhir.Model.Resource
    {
        /// <summary>
        /// Indicates whether the namespace should be used
        /// </summary>
        [FhirEnumeration("NamespaceStatus")]
        public enum NamespaceStatus
        {
            [EnumLiteral("proposed")]
            Proposed, // System has been submitted but not yet approved.
            [EnumLiteral("active")]
            Active, // System is valid for use.
            [EnumLiteral("retired")]
            Retired, // System should no longer be used.
        }
        
        /// <summary>
        /// Identifies the purpose of the namespace
        /// </summary>
        [FhirEnumeration("NamespaceType")]
        public enum NamespaceType
        {
            [EnumLiteral("codesystem")]
            Codesystem, // The namespace is used to define concepts and symbols to represent those concepts.  E.g. UCUM, LOINC, NDC code, local lab codes, etc.
            [EnumLiteral("identifier")]
            Identifier, // The namespace is used to manage identifiers (e.g. license numbers, order numbers, etc.).
            [EnumLiteral("root")]
            Root, // The namespace is used as the root for other identifiers and namespaces.
        }
        
        /// <summary>
        /// Identifies the style of unique identifier used to identify a namepace
        /// </summary>
        [FhirEnumeration("NamespaceIdentifierType")]
        public enum NamespaceIdentifierType
        {
            [EnumLiteral("oid")]
            Oid, // An ISO object identifier.  E.g. 1.2.3.4.5.
            [EnumLiteral("uuid")]
            Uuid, // A universally unique identifier of the form a5afddf4-e880-459b-876e-e4591b0acc11.
            [EnumLiteral("uri")]
            Uri, // A uniform resource identifier (ideally a URL - uniform resource locator).  E.g. http://unitsofmeasure.org.
            [EnumLiteral("ruid")]
            Ruid, // HL7-assigned reserved string.  E.g. LN for LOINC.
        }
        
        /// <summary>
        /// Identifies the general purpose of the namespace identifiers provided
        /// </summary>
        [FhirEnumeration("NamespaceCategory")]
        public enum NamespaceCategory
        {
            [EnumLiteral("driver")]
            Driver, // Driver's license/operator's license.
            [EnumLiteral("provider")]
            Provider, // Provider license or registration id.
            [EnumLiteral("patient")]
            Patient, // Patient record numbers, jurisdictional patient ids, etc.
            [EnumLiteral("bank")]
            Bank, // Credit, debit and other bank card identifiers.
        }
        
        /// <summary>
        /// null
        /// </summary>
        [FhirType("NamespaceContactComponent")]
        [DataContract]
        public partial class NamespaceContactComponent : Hl7.Fhir.Model.Element
        {
            /// <summary>
            /// Name of person
            /// </summary>
            [FhirElement("name", Order=40)]
            [DataMember]
            public Hl7.Fhir.Model.HumanName Name { get; set; }
            
            /// <summary>
            /// Phone, email, etc.
            /// </summary>
            [FhirElement("telecom", Order=50)]
            [Cardinality(Min=0,Max=-1)]
            [DataMember]
            public List<Hl7.Fhir.Model.Contact> Telecom { get; set; }
            
        }
        
        
        /// <summary>
        /// null
        /// </summary>
        [FhirType("NamespaceUniqueIdComponent")]
        [DataContract]
        public partial class NamespaceUniqueIdComponent : Hl7.Fhir.Model.Element
        {
            /// <summary>
            /// oid | uuid | uri | ruid
            /// </summary>
            [FhirElement("type", Order=40)]
            [Cardinality(Min=1,Max=1)]
            [DataMember]
            public Code<Hl7.Fhir.Model.Namespace.NamespaceIdentifierType> TypeElement { get; set; }
            
            [NotMapped]
            [IgnoreDataMemberAttribute]
            public Hl7.Fhir.Model.Namespace.NamespaceIdentifierType? Type
            {
                get { return TypeElement != null ? TypeElement.Value : null; }
                set
                {
                    if(value == null)
                      TypeElement = null; 
                    else
                      TypeElement = new Code<Hl7.Fhir.Model.Namespace.NamespaceIdentifierType>(value);
                }
            }
            
            /// <summary>
            /// The unique identifier
            /// </summary>
            [FhirElement("value", Order=50)]
            [Cardinality(Min=1,Max=1)]
            [DataMember]
            public Hl7.Fhir.Model.FhirString ValueElement { get; set; }
            
            [NotMapped]
            [IgnoreDataMemberAttribute]
            public string Value
            {
                get { return ValueElement != null ? ValueElement.Value : null; }
                set
                {
                    if(value == null)
                      ValueElement = null; 
                    else
                      ValueElement = new Hl7.Fhir.Model.FhirString(value);
                }
            }
            
            /// <summary>
            /// Is this the id that should be used for this type
            /// </summary>
            [FhirElement("preferred", Order=60)]
            [DataMember]
            public Hl7.Fhir.Model.FhirBoolean PreferredElement { get; set; }
            
            [NotMapped]
            [IgnoreDataMemberAttribute]
            public bool? Preferred
            {
                get { return PreferredElement != null ? PreferredElement.Value : null; }
                set
                {
                    if(value == null)
                      PreferredElement = null; 
                    else
                      PreferredElement = new Hl7.Fhir.Model.FhirBoolean(value);
                }
            }
            
            /// <summary>
            /// When is identifier valid?
            /// </summary>
            [FhirElement("period", Order=70)]
            [DataMember]
            public Hl7.Fhir.Model.Period Period { get; set; }
            
        }
        
        
        /// <summary>
        /// codesystem | identifier | root
        /// </summary>
        [FhirElement("type", Order=70)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Code<Hl7.Fhir.Model.Namespace.NamespaceType> TypeElement { get; set; }
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public Hl7.Fhir.Model.Namespace.NamespaceType? Type
        {
            get { return TypeElement != null ? TypeElement.Value : null; }
            set
            {
                if(value == null)
                  TypeElement = null; 
                else
                  TypeElement = new Code<Hl7.Fhir.Model.Namespace.NamespaceType>(value);
            }
        }
        
        /// <summary>
        /// Human-readable name
        /// </summary>
        [FhirElement("label", Order=80)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString LabelElement { get; set; }
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string Label
        {
            get { return LabelElement != null ? LabelElement.Value : null; }
            set
            {
                if(value == null)
                  LabelElement = null; 
                else
                  LabelElement = new Hl7.Fhir.Model.FhirString(value);
            }
        }
        
        /// <summary>
        /// proposed | active | retired
        /// </summary>
        [FhirElement("status", Order=90)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Code<Hl7.Fhir.Model.Namespace.NamespaceStatus> StatusElement { get; set; }
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public Hl7.Fhir.Model.Namespace.NamespaceStatus? Status
        {
            get { return StatusElement != null ? StatusElement.Value : null; }
            set
            {
                if(value == null)
                  StatusElement = null; 
                else
                  StatusElement = new Code<Hl7.Fhir.Model.Namespace.NamespaceStatus>(value);
            }
        }
        
        /// <summary>
        /// ISO 3-char country code
        /// </summary>
        [FhirElement("country", Order=100)]
        [DataMember]
        public Hl7.Fhir.Model.Code CountryElement { get; set; }
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string Country
        {
            get { return CountryElement != null ? CountryElement.Value : null; }
            set
            {
                if(value == null)
                  CountryElement = null; 
                else
                  CountryElement = new Hl7.Fhir.Model.Code(value);
            }
        }
        
        /// <summary>
        /// driver | provider | patient | bank
        /// </summary>
        [FhirElement("category", Order=110)]
        [DataMember]
        public Hl7.Fhir.Model.CodeableConcept Category { get; set; }
        
        /// <summary>
        /// What does namespace identify?
        /// </summary>
        [FhirElement("description", Order=120)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString DescriptionElement { get; set; }
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string Description
        {
            get { return DescriptionElement != null ? DescriptionElement.Value : null; }
            set
            {
                if(value == null)
                  DescriptionElement = null; 
                else
                  DescriptionElement = new Hl7.Fhir.Model.FhirString(value);
            }
        }
        
        /// <summary>
        /// How/where is it used
        /// </summary>
        [FhirElement("usage", Order=130)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString UsageElement { get; set; }
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string Usage
        {
            get { return UsageElement != null ? UsageElement.Value : null; }
            set
            {
                if(value == null)
                  UsageElement = null; 
                else
                  UsageElement = new Hl7.Fhir.Model.FhirString(value);
            }
        }
        
        /// <summary>
        /// Unique identifiers used for system
        /// </summary>
        [FhirElement("uniqueId", Order=140)]
        [Cardinality(Min=1,Max=-1)]
        [DataMember]
        public List<Hl7.Fhir.Model.Namespace.NamespaceUniqueIdComponent> UniqueId { get; set; }
        
        /// <summary>
        /// Who maintains system namespace?
        /// </summary>
        [FhirElement("responsible", Order=150)]
        [DataMember]
        public Hl7.Fhir.Model.ResourceReference Responsible { get; set; }
        
        /// <summary>
        /// Who should be contacted for questions about namespace
        /// </summary>
        [FhirElement("contact", Order=160)]
        [DataMember]
        public Hl7.Fhir.Model.Namespace.NamespaceContactComponent Contact { get; set; }
        
    }
    
}
