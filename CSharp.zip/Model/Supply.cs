﻿using System;
using System.Collections.Generic;
using Hl7.Fhir.Introspection;
using Hl7.Fhir.Validation;
using System.Linq;
using System.Runtime.Serialization;

/*
  Copyright (c) 2011-2013, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

*/

//
// Generated on Tue, Apr 15, 2014 18:09+0000 for FHIR v0.80
//
namespace Hl7.Fhir.Model
{
    /// <summary>
    /// A supply -  request and provision
    /// </summary>
    [FhirType("Supply", IsResource=true)]
    [DataContract]
    public partial class Supply : Hl7.Fhir.Model.Resource, System.ComponentModel.INotifyPropertyChanged
    {
        /// <summary>
        /// Status of the dispense
        /// </summary>
        [FhirEnumeration("SupplyDispenseStatus")]
        public enum SupplyDispenseStatus
        {
            [EnumLiteral("in progress")]
            InProgress, // Supply has been requested, but not dispensed.
            [EnumLiteral("dispensed")]
            Dispensed, // Supply is part of a pharmacy order and has been dispensed.
            [EnumLiteral("abandoned")]
            Abandoned, // Dispensing was not completed.
        }
        
        /// <summary>
        /// Status of the supply
        /// </summary>
        [FhirEnumeration("SupplyStatus")]
        public enum SupplyStatus
        {
            [EnumLiteral("requested")]
            Requested, // Supply has been requested, but not dispensed.
            [EnumLiteral("dispensed")]
            Dispensed, // Supply is part of a pharmacy order and has been dispensed.
            [EnumLiteral("received")]
            Received, // Supply has been received by the requestor.
            [EnumLiteral("failed")]
            Failed, // The supply will not be completed because the supplier was unable or unwilling to supply the item.
            [EnumLiteral("cancelled")]
            Cancelled, // The orderer of the supply cancelled the request.
        }
        
        /// <summary>
        /// null
        /// </summary>
        [FhirType("SupplyDispenseComponent")]
        [DataContract]
        public partial class SupplyDispenseComponent : Hl7.Fhir.Model.Element, System.ComponentModel.INotifyPropertyChanged
        {
            /// <summary>
            /// External identifier
            /// </summary>
            [FhirElement("identifier", Order=40)]
            [DataMember]
            public Hl7.Fhir.Model.Identifier Identifier
            {
                get { return _Identifier; }
                set { _Identifier = value; OnPropertyChanged("Identifier"); }
            }
            private Hl7.Fhir.Model.Identifier _Identifier;
            
            /// <summary>
            /// in progress | dispensed | abandoned
            /// </summary>
            [FhirElement("status", Order=50)]
            [DataMember]
            public Code<Hl7.Fhir.Model.Supply.SupplyDispenseStatus> StatusElement
            {
                get { return _StatusElement; }
                set { _StatusElement = value; OnPropertyChanged("StatusElement"); }
            }
            private Code<Hl7.Fhir.Model.Supply.SupplyDispenseStatus> _StatusElement;
            
            [NotMapped]
            [IgnoreDataMemberAttribute]
            public Hl7.Fhir.Model.Supply.SupplyDispenseStatus? Status
            {
                get { return StatusElement != null ? StatusElement.Value : null; }
                set
                {
                    if(value == null)
                      StatusElement = null; 
                    else
                      StatusElement = new Code<Hl7.Fhir.Model.Supply.SupplyDispenseStatus>(value);
                    OnPropertyChanged("Status");
                }
            }
            
            /// <summary>
            /// Category of dispense event
            /// </summary>
            [FhirElement("type", Order=60)]
            [DataMember]
            public Hl7.Fhir.Model.CodeableConcept Type
            {
                get { return _Type; }
                set { _Type = value; OnPropertyChanged("Type"); }
            }
            private Hl7.Fhir.Model.CodeableConcept _Type;
            
            /// <summary>
            /// Amount dispensed
            /// </summary>
            [FhirElement("quantity", Order=70)]
            [DataMember]
            public Hl7.Fhir.Model.Quantity Quantity
            {
                get { return _Quantity; }
                set { _Quantity = value; OnPropertyChanged("Quantity"); }
            }
            private Hl7.Fhir.Model.Quantity _Quantity;
            
            /// <summary>
            /// Medication, Substance, or Device supplied
            /// </summary>
            [FhirElement("suppliedItem", Order=80)]
            [DataMember]
            public Hl7.Fhir.Model.ResourceReference SuppliedItem
            {
                get { return _SuppliedItem; }
                set { _SuppliedItem = value; OnPropertyChanged("SuppliedItem"); }
            }
            private Hl7.Fhir.Model.ResourceReference _SuppliedItem;
            
            /// <summary>
            /// Dispenser
            /// </summary>
            [FhirElement("supplier", Order=90)]
            [DataMember]
            public Hl7.Fhir.Model.ResourceReference Supplier
            {
                get { return _Supplier; }
                set { _Supplier = value; OnPropertyChanged("Supplier"); }
            }
            private Hl7.Fhir.Model.ResourceReference _Supplier;
            
            /// <summary>
            /// Dispensing time
            /// </summary>
            [FhirElement("whenPrepared", Order=100)]
            [DataMember]
            public Hl7.Fhir.Model.Period WhenPrepared
            {
                get { return _WhenPrepared; }
                set { _WhenPrepared = value; OnPropertyChanged("WhenPrepared"); }
            }
            private Hl7.Fhir.Model.Period _WhenPrepared;
            
            /// <summary>
            /// Handover time
            /// </summary>
            [FhirElement("whenHandedOver", Order=110)]
            [DataMember]
            public Hl7.Fhir.Model.Period WhenHandedOver
            {
                get { return _WhenHandedOver; }
                set { _WhenHandedOver = value; OnPropertyChanged("WhenHandedOver"); }
            }
            private Hl7.Fhir.Model.Period _WhenHandedOver;
            
            /// <summary>
            /// Where the Supply was sent
            /// </summary>
            [FhirElement("destination", Order=120)]
            [DataMember]
            public Hl7.Fhir.Model.ResourceReference Destination
            {
                get { return _Destination; }
                set { _Destination = value; OnPropertyChanged("Destination"); }
            }
            private Hl7.Fhir.Model.ResourceReference _Destination;
            
            /// <summary>
            /// Who collected the Supply
            /// </summary>
            [FhirElement("receiver", Order=130)]
            [Cardinality(Min=0,Max=-1)]
            [DataMember]
            public List<Hl7.Fhir.Model.ResourceReference> Receiver
            {
                get { return _Receiver; }
                set { _Receiver = value; OnPropertyChanged("Receiver"); }
            }
            private List<Hl7.Fhir.Model.ResourceReference> _Receiver;
            
        }
        
        
        /// <summary>
        /// The kind of supply (central, non-stock, etc)
        /// </summary>
        [FhirElement("kind", Order=70)]
        [DataMember]
        public Hl7.Fhir.Model.CodeableConcept Kind
        {
            get { return _Kind; }
            set { _Kind = value; OnPropertyChanged("Kind"); }
        }
        private Hl7.Fhir.Model.CodeableConcept _Kind;
        
        /// <summary>
        /// Unique identifier
        /// </summary>
        [FhirElement("identifier", Order=80)]
        [DataMember]
        public Hl7.Fhir.Model.Identifier Identifier
        {
            get { return _Identifier; }
            set { _Identifier = value; OnPropertyChanged("Identifier"); }
        }
        private Hl7.Fhir.Model.Identifier _Identifier;
        
        /// <summary>
        /// requested | dispensed | received | failed | cancelled
        /// </summary>
        [FhirElement("status", Order=90)]
        [DataMember]
        public Code<Hl7.Fhir.Model.Supply.SupplyStatus> StatusElement
        {
            get { return _StatusElement; }
            set { _StatusElement = value; OnPropertyChanged("StatusElement"); }
        }
        private Code<Hl7.Fhir.Model.Supply.SupplyStatus> _StatusElement;
        
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public Hl7.Fhir.Model.Supply.SupplyStatus? Status
        {
            get { return StatusElement != null ? StatusElement.Value : null; }
            set
            {
                if(value == null)
                  StatusElement = null; 
                else
                  StatusElement = new Code<Hl7.Fhir.Model.Supply.SupplyStatus>(value);
                OnPropertyChanged("Status");
            }
        }
        
        /// <summary>
        /// Medication, Substance, or Device requested to be supplied
        /// </summary>
        [FhirElement("orderedItem", Order=100)]
        [DataMember]
        public Hl7.Fhir.Model.ResourceReference OrderedItem
        {
            get { return _OrderedItem; }
            set { _OrderedItem = value; OnPropertyChanged("OrderedItem"); }
        }
        private Hl7.Fhir.Model.ResourceReference _OrderedItem;
        
        /// <summary>
        /// Patient for whom the item is supplied
        /// </summary>
        [FhirElement("patient", Order=110)]
        [DataMember]
        public Hl7.Fhir.Model.ResourceReference Patient
        {
            get { return _Patient; }
            set { _Patient = value; OnPropertyChanged("Patient"); }
        }
        private Hl7.Fhir.Model.ResourceReference _Patient;
        
        /// <summary>
        /// Supply details
        /// </summary>
        [FhirElement("dispense", Order=120)]
        [Cardinality(Min=0,Max=-1)]
        [DataMember]
        public List<Hl7.Fhir.Model.Supply.SupplyDispenseComponent> Dispense
        {
            get { return _Dispense; }
            set { _Dispense = value; OnPropertyChanged("Dispense"); }
        }
        private List<Hl7.Fhir.Model.Supply.SupplyDispenseComponent> _Dispense;
        
    }
    
}
